const {Ping} = require('./ping');

/**
 * A named vehicle with a sequence of pings.
 */
class Vehicle {
  /**
   * @param {string} name
   */
  constructor(name) {
    /** @private @const */
    this.name = name;

    /** @private @const {!Array<!Ping>} */
    this.pings = [];
  }

  /**
   * The name of the vehicle.
   * @return {string}
   */
  getName() {
    return this.name;
  }

  /**
   * The pings for the vehicle, in chronological order (earliest first).
   * @return {!Array<!Ping>}
   */
  getPings() {
    return this.pings;
  }

  /**
   * Determines the total distance covered by the pings.
   * @param {!Array<!Ping>} pings
   * @return {number}
   */
  static getTotalDistance(pings) {
    // TODO: implement
    return 0;
  }

  /**
   * Determines the total distance traveled by the vehicle.
   * @return {number}
   */
  getTotalDistance() {
    return Vehicle.getTotalDistance(this.pings);
  }

  /**
   * Determines the average speed of the vehicle.
   * @return {number}
   */
  getAverageSpeed() {
    // TODO: implement
    return 0;
  }
}

module.exports = {Vehicle};
