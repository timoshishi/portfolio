#!/usr/bin/env bash

node runner.js
